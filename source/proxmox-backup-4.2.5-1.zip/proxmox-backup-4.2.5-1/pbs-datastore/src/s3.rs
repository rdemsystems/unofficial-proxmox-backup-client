use std::path::{Path, PathBuf};

use anyhow::{Error, bail, format_err};
use hex::FromHex;

use proxmox_s3_client::{DeleteObjectError, S3ObjectKey};

/// Object key prefix to group regular datastore contents (not chunks)
pub const S3_CONTENT_PREFIX: &str = ".cnt";

/// Generate a relative object key with content prefix from given path and filename
pub fn object_key_from_path(path: &Path, filename: &str) -> Result<S3ObjectKey, Error> {
    // Force the use of relative paths, otherwise this would loose the content prefix
    if path.is_absolute() {
        bail!("cannot generate object key from absolute path");
    }
    if filename.contains('/') {
        bail!("invalid filename containing slashes");
    }
    let mut object_path = PathBuf::from(S3_CONTENT_PREFIX);
    object_path.push(path);
    object_path.push(filename);

    let object_key_str = object_path
        .to_str()
        .ok_or_else(|| format_err!("unexpected object key path"))?;
    S3ObjectKey::try_from(object_key_str)
}

/// Generate a relative object key with chunk prefix from given digest
pub fn object_key_from_digest(digest: &[u8; 32]) -> Result<S3ObjectKey, Error> {
    let object_key = hex::encode(digest);
    let digest_prefix = &object_key[..4];
    let object_key_string = format!(".chunks/{digest_prefix}/{object_key}");
    S3ObjectKey::try_from(object_key_string.as_str())
}

/// Generate a relative object key with chunk prefix from given digest, extended by suffix
pub fn object_key_from_digest_with_suffix(
    digest: &[u8; 32],
    suffix: &str,
) -> Result<S3ObjectKey, Error> {
    if suffix.contains('/') {
        bail!("invalid suffix containing slashes");
    }
    let object_key = hex::encode(digest);
    let digest_prefix = &object_key[..4];
    let object_key_string = format!(".chunks/{digest_prefix}/{object_key}{suffix}");
    S3ObjectKey::try_from(object_key_string.as_str())
}

/// Extract filename, digest, and suffix from the last part of an S3ObjectKey.
pub(crate) fn digest_from_object_key(key: &S3ObjectKey) -> Option<(&str, [u8; 32], &str)> {
    let filename = key.rsplit('/').next()?;
    let (hex_digest, suffix) = filename.split_at_checked(64)?;

    let digest = FromHex::from_hex(hex_digest).ok()?;

    Some((filename, digest, suffix))
}

/// Log errors from delete objects api calls
pub(crate) fn log_s3_delete_objects_errors(errors: &[DeleteObjectError]) {
    for error in errors {
        log::error!(
            "delete object failed: {} {} {}",
            error
                .key
                .as_ref()
                .map(|key| key.to_string())
                .unwrap_or_else(|| "None".into()),
            error.code.as_deref().unwrap_or("None"),
            error.message.as_deref().unwrap_or("None"),
        );
    }
}

#[test]
fn test_object_key_from_path() {
    let path = Path::new("vm/100/2025-07-14T14:20:02Z");
    let filename = "drive-scsci0.img.fidx";
    assert_eq!(
        object_key_from_path(path, filename).unwrap().to_string(),
        ".cnt/vm/100/2025-07-14T14:20:02Z/drive-scsci0.img.fidx",
    );
}

#[test]
fn test_object_key_from_empty_path() {
    let path = Path::new("");
    let filename = ".marker";
    assert_eq!(
        object_key_from_path(path, filename).unwrap().to_string(),
        ".cnt/.marker",
    );
}

#[test]
fn test_object_key_from_absolute_path() {
    assert!(object_key_from_path(Path::new("/"), ".marker").is_err());
}

#[test]
fn test_object_key_from_path_incorrect_filename() {
    assert!(object_key_from_path(Path::new(""), "/.marker").is_err());
}

#[test]
fn test_object_key_from_digest() {
    let digest =
        <[u8; 32]>::from_hex("bb9f8df61474d25e71fa00722318cd387396ca1736605e1248821cc0de3d3af8")
            .unwrap();
    assert_eq!(
        object_key_from_digest(&digest).unwrap().to_string(),
        ".chunks/bb9f/bb9f8df61474d25e71fa00722318cd387396ca1736605e1248821cc0de3d3af8",
    );
}

#[test]
fn test_object_key_from_digest_with_suffix() {
    let digest =
        <[u8; 32]>::from_hex("bb9f8df61474d25e71fa00722318cd387396ca1736605e1248821cc0de3d3af8")
            .unwrap();
    assert_eq!(
        object_key_from_digest_with_suffix(&digest, ".0.bad")
            .unwrap()
            .to_string(),
        ".chunks/bb9f/bb9f8df61474d25e71fa00722318cd387396ca1736605e1248821cc0de3d3af8.0.bad",
    );
}

#[test]
fn test_object_key_from_digest_with_invalid_suffix() {
    let digest =
        <[u8; 32]>::from_hex("bb9f8df61474d25e71fa00722318cd387396ca1736605e1248821cc0de3d3af8")
            .unwrap();
    assert!(object_key_from_digest_with_suffix(&digest, "/.0.bad").is_err());
}

#[test]
fn test_digest_from_object_key() {
    let hex = "bb9f8df61474d25e71fa00722318cd387396ca1736605e1248821cc0de3d3af8";
    let digest = <[u8; 32]>::from_hex(hex).unwrap();
    let k = |s: &str| S3ObjectKey::try_from(s).unwrap();

    assert_eq!(digest_from_object_key(&k(&hex[1..])), None);
    let invalid_hex = hex.replace("b", "X");
    assert_eq!(digest_from_object_key(&k(&invalid_hex)), None);

    assert_eq!(digest_from_object_key(&k(hex)), Some((hex, digest, "")));

    let k1 = object_key_from_digest_with_suffix(&digest, "suffix1").unwrap();
    assert_eq!(
        digest_from_object_key(&k1),
        Some((format!("{hex}suffix1").as_str(), digest, "suffix1"))
    );

    let k2 = S3ObjectKey::try_from(format!(".chunks/bb9f/{hex}.0.bad").as_str()).unwrap();
    assert_eq!(
        digest_from_object_key(&k2),
        Some((format!("{hex}.0.bad").as_str(), digest, ".0.bad"))
    );
}
