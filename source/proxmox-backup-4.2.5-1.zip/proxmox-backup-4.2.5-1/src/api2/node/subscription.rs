use anyhow::{Error, bail, format_err};
use serde_json::Value;

use proxmox_http::HttpOptions;
use proxmox_http::client::Client;
use proxmox_router::{Permission, Router, RpcEnvironment};
use proxmox_schema::api;
use proxmox_subscription::{
    SetSubscription, SubscriptionInfo, SubscriptionStatus, UpdateSubscription,
};
use proxmox_sys::fs::CreateOptions;

use pbs_api_types::{Authid, NODE_SCHEMA, PRIV_SYS_AUDIT, PRIV_SYS_MODIFY};

use crate::tools::{DEFAULT_USER_AGENT_STRING, PROXMOX_BACKUP_TCP_KEEPALIVE_TIME};

use pbs_buildcfg::PROXMOX_BACKUP_SUBSCRIPTION_FN;
use pbs_config::CachedUserInfo;
use pbs_config::node;

const PRODUCT_URL: &str = "https://www.proxmox.com/en/proxmox-backup-server/pricing";
const APT_AUTH_FN: &str = "/etc/apt/auth.conf.d/pbs.conf";
const APT_AUTH_URL: &str = "enterprise.proxmox.com/debian/pbs";

fn apt_auth_file_opts() -> CreateOptions {
    let mode = nix::sys::stat::Mode::from_bits_truncate(0o0600);
    CreateOptions::new().perm(mode).owner(nix::unistd::ROOT)
}

/// arm64 subscription keys carry an explicit '-arm-' marker that x86 keys lack, so a key is bound
/// to the architecture it was issued for. Returns an error if `key` is for a different architecture
/// than this host. The daemon is compiled for the host it runs on, so the host architecture is
/// known at compile time and no runtime `dpkg` query is needed.
pub fn check_key_arch(key: &str) -> Result<(), Error> {
    let key_is_arm64 = key.contains("-arm-");
    let host_is_arm64 = cfg!(target_arch = "aarch64");
    if key_is_arm64 != host_is_arm64 {
        let key_arch = if key_is_arm64 { "arm64" } else { "amd64" };
        let host_arch = if host_is_arm64 { "arm64" } else { "amd64" };
        bail!(
            "subscription key is for the '{key_arch}' architecture, but this host is '{host_arch}'"
        );
    }
    Ok(())
}

fn check_and_write_subscription(key: String, server_id: String) -> Result<(), Error> {
    let proxy_config = if let Ok((node_config, _digest)) = node::config() {
        node_config.http_proxy()
    } else {
        None
    };

    let client = Client::with_options(HttpOptions {
        proxy_config,
        user_agent: Some(DEFAULT_USER_AGENT_STRING.to_string()),
        tcp_keepalive: Some(PROXMOX_BACKUP_TCP_KEEPALIVE_TIME),
    });

    let info = proxmox_subscription::check::check_subscription(
        key,
        server_id,
        PRODUCT_URL.to_string(),
        client,
    )?;

    proxmox_subscription::files::write_subscription(
        PROXMOX_BACKUP_SUBSCRIPTION_FN,
        proxmox_product_config::privileged_create_options(),
        &info,
    )
    .map_err(|e| format_err!("Error writing updated subscription status - {}", e))?;

    proxmox_subscription::files::update_apt_auth(
        APT_AUTH_FN,
        apt_auth_file_opts(),
        APT_AUTH_URL,
        info.key,
        info.serverid,
    )
}

#[api(
    input: {
        properties: {
            node: {
                schema: NODE_SCHEMA,
            },
            params: {
                type: UpdateSubscription,
                flatten: true,
            },
        },
    },
    protected: true,
    access: {
        permission: &Permission::Privilege(&["system"], PRIV_SYS_MODIFY, false),
    },
)]
/// Check and update subscription status.
pub fn check_subscription(params: UpdateSubscription) -> Result<(), Error> {
    let force = params.force.unwrap_or(false);
    let mut info = match proxmox_subscription::files::read_subscription(
        PROXMOX_BACKUP_SUBSCRIPTION_FN,
        &[proxmox_subscription::files::DEFAULT_SIGNING_KEY],
    ) {
        Err(err) => bail!("could not read subscription status: {}", err),
        Ok(Some(info)) => info,
        Ok(None) => return Ok(()),
    };

    let server_id = if let Some(existing) = info.serverid.as_ref() {
        existing.to_owned()
    } else {
        proxmox_subscription::get_hardware_address_candidates()?
            .first()
            .ok_or_else(|| format_err!("Failed to generate serverid"))?
            .to_string()
    };

    let key = if let Some(key) = info.key.as_ref() {
        // must run before the early return for a still-active subscription further below
        check_key_arch(key)?;
        // always update apt auth if we have a key to ensure user can access enterprise repo
        proxmox_subscription::files::update_apt_auth(
            APT_AUTH_FN,
            apt_auth_file_opts(),
            APT_AUTH_URL,
            Some(key.to_owned()),
            Some(server_id.clone()),
        )?;
        key.to_owned()
    } else {
        String::new()
    };

    if info.is_signed() {
        bail!(
            "Updating offline key not possible - please remove and re-add subscription key to switch to online key."
        );
    }

    if !force && info.status == SubscriptionStatus::Active {
        // will set to INVALID if last check too long ago
        info.check_age(true);

        if info.status == SubscriptionStatus::Active {
            return Ok(());
        }
    }

    check_and_write_subscription(key, server_id)
}

#[api(
    input: {
        properties: {
            node: {
                schema: NODE_SCHEMA,
            },
        },
    },
    returns: { type: SubscriptionInfo },
    access: {
        permission: &Permission::Anybody,
    },
)]
/// Read subscription info.
pub fn get_subscription(
    _param: Value,
    rpcenv: &mut dyn RpcEnvironment,
) -> Result<SubscriptionInfo, Error> {
    let mut info = match proxmox_subscription::files::read_subscription(
        PROXMOX_BACKUP_SUBSCRIPTION_FN,
        &[proxmox_subscription::files::DEFAULT_SIGNING_KEY],
    ) {
        Err(err) => bail!("could not read subscription status: {}", err),
        Ok(Some(info)) => info,
        Ok(None) => {
            let candidates = proxmox_subscription::get_hardware_address_candidates()?;
            let serverid = candidates
                .first()
                .ok_or_else(|| format_err!("Failed to generate serverid"))?;
            SubscriptionInfo {
                status: SubscriptionStatus::NotFound,
                message: Some("There is no subscription key".into()),
                serverid: Some(serverid.to_string()),
                url: Some(PRODUCT_URL.into()),
                ..Default::default()
            }
        }
    };

    // an offline key can be written directly and a key file can be copied between hosts, so flag a
    // stored key that does not match this host's architecture, mirroring the reject on 'set'.
    if let Some(key) = info.key.as_deref() {
        if let Err(err) = check_key_arch(key) {
            info.status = SubscriptionStatus::Invalid;
            info.message = Some(err.to_string());
        }
    }

    let auth_id: Authid = rpcenv.get_auth_id().unwrap().parse()?;
    let user_info = CachedUserInfo::new()?;
    let user_privs = user_info.lookup_privs(&auth_id, &[]);

    if (user_privs & PRIV_SYS_AUDIT) == 0 {
        // not enough privileges for full state
        return Ok(SubscriptionInfo {
            status: info.status,
            message: info.message,
            url: info.url,
            ..Default::default()
        });
    };

    Ok(info)
}

#[api(
    input: {
        properties: {
            node: {
                schema: NODE_SCHEMA,
            },
            params: {
                type: SetSubscription,
                flatten: true,
            },
        },
    },
    protected: true,
    access: {
        permission: &Permission::Privilege(&["system"], PRIV_SYS_MODIFY, false),
    },
)]
/// Set a subscription key and check it.
pub fn set_subscription(params: SetSubscription) -> Result<(), Error> {
    // SetSubscription stays product-neutral; enforce the PBS key pattern locally so bad keys fail fast.
    pbs_api_types::SUBSCRIPTION_KEY_SCHEMA
        .parse_simple_value(&params.key)
        .map_err(|err| format_err!("invalid subscription key: {err}"))?;

    // a key is bound to the architecture it was issued for, so reject a mismatched one
    check_key_arch(&params.key)?;

    let server_id = proxmox_subscription::get_hardware_address_candidates()?
        .first()
        .ok_or_else(|| format_err!("Failed to generate serverid"))?
        .to_string();

    check_and_write_subscription(params.key, server_id)
}

#[api(
    input: {
        properties: {
            node: {
                schema: NODE_SCHEMA,
            },
        },
    },
    protected: true,
    access: {
        permission: &Permission::Privilege(&["system"], PRIV_SYS_MODIFY, false),
    },
)]
/// Delete subscription info.
pub fn delete_subscription() -> Result<(), Error> {
    proxmox_subscription::files::delete_subscription(PROXMOX_BACKUP_SUBSCRIPTION_FN)
        .map_err(|err| format_err!("Deleting subscription failed: {}", err))?;

    proxmox_subscription::files::update_apt_auth(
        APT_AUTH_FN,
        apt_auth_file_opts(),
        APT_AUTH_URL,
        None,
        None,
    )?;

    Ok(())
}

pub const ROUTER: Router = Router::new()
    .post(&API_METHOD_CHECK_SUBSCRIPTION)
    .put(&API_METHOD_SET_SUBSCRIPTION)
    .delete(&API_METHOD_DELETE_SUBSCRIPTION)
    .get(&API_METHOD_GET_SUBSCRIPTION);
