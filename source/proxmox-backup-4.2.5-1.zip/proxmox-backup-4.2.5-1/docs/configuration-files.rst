Configuration Files
===================

All `Proxmox Backup`_ Server configuration files reside in the directory
``/etc/proxmox-backup/``.


``acl.cfg``
~~~~~~~~~~~~~~~~~

File Format
^^^^^^^^^^^

.. include:: config/acl/format.rst


Roles
^^^^^

The following roles exist:

.. include:: config/acl/roles.rst


``datastore.cfg``
~~~~~~~~~~~~~~~~~

File Format
^^^^^^^^^^^

.. include:: config/datastore/format.rst


Options
^^^^^^^

.. include:: config/datastore/config.rst

.. _domains.cfg:

``domains.cfg``
~~~~~~~~~~~~~~~

File Format
^^^^^^^^^^^

.. include:: config/domains/format.rst


Options
^^^^^^^

.. include:: config/domains/config.rst


``media-pool.cfg``
~~~~~~~~~~~~~~~~~~

File Format
^^^^^^^^^^^

.. include:: config/media-pool/format.rst


Options
^^^^^^^

.. include:: config/media-pool/config.rst

``node.cfg``
~~~~~~~~~~~~~~~~~~

Options
^^^^^^^

.. include:: config/node/format.rst

.. _notifications.cfg:

``notifications.cfg``
~~~~~~~~~~~~~~~~~~~~~

File Format
^^^^^^^^^^^

.. include:: config/notifications/format.rst


Options
^^^^^^^

.. include:: config/notifications/config.rst

.. _notifications_priv.cfg:

``notifications-priv.cfg``
~~~~~~~~~~~~~~~~~~~~~~~~~~

File Format
^^^^^^^^^^^

.. include:: config/notifications-priv/format.rst


Options
^^^^^^^

.. include:: config/notifications-priv/config.rst


``prune.cfg``
~~~~~~~~~~~~~

File Format
^^^^^^^^^^^

.. include:: config/prune/format.rst


Options
^^^^^^^

.. include:: config/prune/config.rst


``tape.cfg``
~~~~~~~~~~~~

File Format
^^^^^^^^^^^

.. include:: config/tape/format.rst


Options
^^^^^^^

.. include:: config/tape/config.rst


``tape-job.cfg``
~~~~~~~~~~~~~~~~

File Format
^^^^^^^^^^^

.. include:: config/tape-job/format.rst


Options
^^^^^^^

.. include:: config/tape-job/config.rst


``user.cfg``
~~~~~~~~~~~~

File Format
^^^^^^^^^^^

.. include:: config/user/format.rst


Options
^^^^^^^

.. include:: config/user/config.rst


``remote.cfg``
~~~~~~~~~~~~~~~~~

File Format
^^^^^^^^^^^

.. include:: config/remote/format.rst


Options
^^^^^^^

.. include:: config/remote/config.rst


``sync.cfg``
~~~~~~~~~~~~~~~~~

File Format
^^^^^^^^^^^

.. include:: config/sync/format.rst


Options
^^^^^^^

.. include:: config/sync/config.rst


``verification.cfg``
~~~~~~~~~~~~~~~~~~~~

File Format
^^^^^^^^^^^

.. include:: config/verification/format.rst


Options
^^^^^^^

.. include:: config/verification/config.rst
