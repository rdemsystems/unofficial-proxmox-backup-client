const proxmoxOnlineHelpInfo = {
  "pbs_documentation_index": {
    "link": "/docs/index.html",
    "title": "Proxmox Backup Server Documentation Index"
  },
  "client-usage": {
    "link": "/docs/backup-client.html#client-usage",
    "title": "Backup Client Usage"
  },
  "client-repository": {
    "link": "/docs/backup-client.html#client-repository",
    "title": "Backup Repository Locations"
  },
  "statically-linked-client": {
    "link": "/docs/backup-client.html#statically-linked-client",
    "title": "Statically Linked Backup Client"
  },
  "environment-variables": {
    "link": "/docs/backup-client.html#environment-variables",
    "title": "Environment Variables"
  },
  "client-creating-backups": {
    "link": "/docs/backup-client.html#client-creating-backups",
    "title": "Creating Backups"
  },
  "client-change-detection-mode": {
    "link": "/docs/backup-client.html#client-change-detection-mode",
    "title": "Change Detection Mode"
  },
  "client-encryption": {
    "link": "/docs/backup-client.html#client-encryption",
    "title": "Encryption"
  },
  "client-restoring-data": {
    "link": "/docs/backup-client.html#client-restoring-data",
    "title": "Restoring Data"
  },
  "changing-backup-owner": {
    "link": "/docs/backup-client.html#changing-backup-owner",
    "title": "Changing the Owner of a Backup Group"
  },
  "backup-pruning": {
    "link": "/docs/backup-client.html#backup-pruning",
    "title": "Pruning and Removing Backups"
  },
  "client-garbage-collection": {
    "link": "/docs/backup-client.html#client-garbage-collection",
    "title": "Garbage Collection"
  },
  "calendar-event-scheduling": {
    "link": "/docs/calendarevents.html#calendar-event-scheduling",
    "title": "Calendar Events"
  },
  "domains-cfg": {
    "link": "/docs/configuration-files.html#domains-cfg",
    "title": "``domains.cfg``"
  },
  "notifications-cfg": {
    "link": "/docs/configuration-files.html#notifications-cfg",
    "title": "``notifications.cfg``"
  },
  "notifications-priv-cfg": {
    "link": "/docs/configuration-files.html#notifications-priv-cfg",
    "title": "``notifications-priv.cfg``"
  },
  "faq-support-table": {
    "link": "/docs/faq.html#faq-support-table",
    "title": "How long will my Proxmox Backup Server version be supported?"
  },
  "faq-upgrade-major": {
    "link": "/docs/faq.html#faq-upgrade-major",
    "title": "How can I upgrade Proxmox Backup Server to the next major release?"
  },
  "pxar-format": {
    "link": "/docs/file-formats.html#pxar-format",
    "title": "Proxmox File Archive Format (``.pxar``)"
  },
  "pxar-meta-format": {
    "link": "/docs/file-formats.html#pxar-meta-format",
    "title": "Proxmox File Archive Format - Meta (``.mpxar``)"
  },
  "ppxar-format": {
    "link": "/docs/file-formats.html#ppxar-format",
    "title": "Proxmox File Archive Format - Payload (``.ppxar``)"
  },
  "pcat1-format": {
    "link": "/docs/file-formats.html#pcat1-format",
    "title": "Proxmox Catalog File Format (``.pcat1``)"
  },
  "pcat1-catalog-data": {
    "link": "/docs/file-formats.html#pcat1-catalog-data",
    "title": "Catalog Data Tables"
  },
  "pcat1-entry-layout": {
    "link": "/docs/file-formats.html#pcat1-entry-layout",
    "title": "Catalog Table Entries"
  },
  "pcat1-entry-types": {
    "link": "/docs/file-formats.html#pcat1-entry-types",
    "title": "Entry Types:"
  },
  "data-blob-format": {
    "link": "/docs/file-formats.html#data-blob-format",
    "title": "Data Blob Format (``.blob``)"
  },
  "fixed-index-format": {
    "link": "/docs/file-formats.html#fixed-index-format",
    "title": "Fixed Index Format  (``.fidx``)"
  },
  "dynamic-index-format": {
    "link": "/docs/file-formats.html#dynamic-index-format",
    "title": "Dynamic Index Format (``.didx``)"
  },
  "consent-banner": {
    "link": "/docs/gui.html#consent-banner",
    "title": "Consent Banner"
  },
  "minimum-system-requirements": {
    "link": "/docs/system-requirements.html#minimum-system-requirements",
    "title": "Minimum Server Requirements, for Evaluation"
  },
  "installation-medium": {
    "link": "/docs/installation-media.html#installation-medium",
    "title": "Installation Medium"
  },
  "install-pbs": {
    "link": "/docs/installation.html#install-pbs",
    "title": "Server Installation"
  },
  "using-the-installer": {
    "link": "/docs/using-the-installer.html#using-the-installer",
    "title": "Install `Proxmox Backup`_ Server using the Installer"
  },
  "advanced-lvm-options": {
    "link": "/docs/using-the-installer.html#advanced-lvm-options",
    "title": "Advanced LVM Configuration Options"
  },
  "advanced-zfs-options": {
    "link": "/docs/using-the-installer.html#advanced-zfs-options",
    "title": "Advanced ZFS Configuration Options"
  },
  "nomodeset-kernel-param": {
    "link": "/docs/using-the-installer.html#nomodeset-kernel-param",
    "title": "Adding the ``nomodeset`` Kernel Parameter"
  },
  "install-pbs-unattended": {
    "link": "/docs/installation.html#install-pbs-unattended",
    "title": "Install `Proxmox Backup`_ Server Unattended"
  },
  "install-pbs-on-debian": {
    "link": "/docs/installation.html#install-pbs-on-debian",
    "title": "Install `Proxmox Backup`_ Server on Debian"
  },
  "install-pbs-on-pve": {
    "link": "/docs/installation.html#install-pbs-on-pve",
    "title": "Install Proxmox Backup Server on `Proxmox VE`_"
  },
  "install-pbc": {
    "link": "/docs/installation.html#install-pbc",
    "title": "Client Installation"
  },
  "sysadmin-package-repositories": {
    "link": "/docs/installation.html#sysadmin-package-repositories",
    "title": "Debian Package Repositories"
  },
  "package-repos-repository-formats": {
    "link": "/docs/installation.html#package-repos-repository-formats",
    "title": "Repository Formats"
  },
  "package-repos-debian-base-repositories": {
    "link": "/docs/installation.html#package-repos-debian-base-repositories",
    "title": "Debian Base Repositories"
  },
  "sysadmin-package-repos-enterprise": {
    "link": "/docs/installation.html#sysadmin-package-repos-enterprise",
    "title": "`Proxmox Backup`_ Enterprise Repository"
  },
  "package-repositories-dbgsym": {
    "link": "/docs/installation.html#package-repositories-dbgsym",
    "title": "`Proxmox Backup`_ Debug Symbol Repository"
  },
  "package-repositories-client-only": {
    "link": "/docs/installation.html#package-repositories-client-only",
    "title": "Proxmox Backup Client-only Repository"
  },
  "package-repositories-client-only-apt": {
    "link": "/docs/installation.html#package-repositories-client-only-apt",
    "title": "APT-based Proxmox Backup Client Repository"
  },
  "package-repos-secure-apt": {
    "link": "/docs/installation.html#package-repos-secure-apt",
    "title": "SecureApt"
  },
  "node-options-http-proxy": {
    "link": "/docs/installation.html#node-options-http-proxy",
    "title": "Repository Access Behind HTTP Proxy"
  },
  "get-help": {
    "link": "/docs/introduction.html#get-help",
    "title": "Getting Help"
  },
  "get-help-enterprise-support": {
    "link": "/docs/introduction.html#get-help-enterprise-support",
    "title": "Enterprise Support"
  },
  "maintenance-pruning": {
    "link": "/docs/maintenance.html#maintenance-pruning",
    "title": "Pruning"
  },
  "maintenance-prune-jobs": {
    "link": "/docs/maintenance.html#maintenance-prune-jobs",
    "title": "Prune Jobs"
  },
  "maintenance-gc": {
    "link": "/docs/maintenance.html#maintenance-gc",
    "title": "Garbage Collection"
  },
  "gc-background": {
    "link": "/docs/maintenance.html#gc-background",
    "title": "GC Background"
  },
  "maintenance-verification": {
    "link": "/docs/maintenance.html#maintenance-verification",
    "title": "Verification"
  },
  "maintenance-notification": {
    "link": "/docs/maintenance.html#maintenance-notification",
    "title": "Notifications"
  },
  "maintenance-mode": {
    "link": "/docs/maintenance.html#maintenance-mode",
    "title": "Maintenance Mode"
  },
  "backup-remote": {
    "link": "/docs/managing-remotes.html#backup-remote",
    "title": "Remote"
  },
  "syncjobs": {
    "link": "/docs/managing-remotes.html#syncjobs",
    "title": "Sync Jobs"
  },
  "markdown-primer": {
    "link": "/docs/markdown-primer.html#markdown-primer",
    "title": "Markdown Primer"
  },
  "markdown-basics": {
    "link": "/docs/markdown-primer.html#markdown-basics",
    "title": "Markdown Basics"
  },
  "sysadmin-network-configuration": {
    "link": "/docs/network-management.html#sysadmin-network-configuration",
    "title": "Network Management"
  },
  "sysadmin-traffic-control": {
    "link": "/docs/network-management.html#sysadmin-traffic-control",
    "title": "Traffic Control"
  },
  "notifications": {
    "link": "/docs/notifications.html#notifications",
    "title": "Notifications"
  },
  "notification-targets": {
    "link": "/docs/notifications.html#notification-targets",
    "title": "Notification Targets"
  },
  "notification-targets-sendmail": {
    "link": "/docs/notifications.html#notification-targets-sendmail",
    "title": "Sendmail"
  },
  "notification-targets-smtp": {
    "link": "/docs/notifications.html#notification-targets-smtp",
    "title": "SMTP"
  },
  "notification-targets-gotify": {
    "link": "/docs/notifications.html#notification-targets-gotify",
    "title": "Gotify"
  },
  "notification-targets-webhook": {
    "link": "/docs/notifications.html#notification-targets-webhook",
    "title": "Webhook"
  },
  "notification-matchers": {
    "link": "/docs/notifications.html#notification-matchers",
    "title": "Notification Matchers"
  },
  "notification-events": {
    "link": "/docs/notifications.html#notification-events",
    "title": "Notification Events"
  },
  "notification-mode": {
    "link": "/docs/notifications.html#notification-mode",
    "title": "Notification Mode"
  },
  "s3-notification-thresholds": {
    "link": "/docs/notifications.html#s3-notification-thresholds",
    "title": "Notification Thresholds and Reset Schedule (S3 Datastores Only)"
  },
  "pve-integration": {
    "link": "/docs/pve-integration.html#pve-integration",
    "title": "`Proxmox VE`_ Integration"
  },
  "storage-disk-management": {
    "link": "/docs/storage.html#storage-disk-management",
    "title": "Disk Management"
  },
  "datastore-intro": {
    "link": "/docs/storage.html#datastore-intro",
    "title": "Datastore"
  },
  "storage-datastore-create": {
    "link": "/docs/storage.html#storage-datastore-create",
    "title": "Creating a Datastore"
  },
  "datastore-s3-backend": {
    "link": "/docs/storage.html#datastore-s3-backend",
    "title": "Datastores with S3 Backend"
  },
  "datastore-s3-endpoint-examples": {
    "link": "/docs/storage.html#datastore-s3-endpoint-examples",
    "title": "S3 Datastore Backend Configuration Examples"
  },
  "storage-namespaces": {
    "link": "/docs/storage.html#storage-namespaces",
    "title": "Backup Namespaces"
  },
  "storage-move-namespaces-groups": {
    "link": "/docs/storage.html#storage-move-namespaces-groups",
    "title": "Moving Namespaces and Groups"
  },
  "datastore-options": {
    "link": "/docs/storage.html#datastore-options",
    "title": "Options"
  },
  "datastore-tuning-options": {
    "link": "/docs/storage.html#datastore-tuning-options",
    "title": "Tuning"
  },
  "ransomware-protection": {
    "link": "/docs/storage.html#ransomware-protection",
    "title": "Ransomware Protection & Recovery"
  },
  "sysadmin-host-administration": {
    "link": "/docs/sysadmin.html#sysadmin-host-administration",
    "title": "Host System Administration"
  },
  "chapter-zfs": {
    "link": "/docs/sysadmin.html#chapter-zfs",
    "title": "ZFS on Linux"
  },
  "zfs-swap": {
    "link": "/docs/sysadmin.html#zfs-swap",
    "title": "Swap on ZFS"
  },
  "local-zfs-special-device": {
    "link": "/docs/sysadmin.html#local-zfs-special-device",
    "title": "ZFS special device"
  },
  "chapter-systembooting": {
    "link": "/docs/sysadmin.html#chapter-systembooting",
    "title": "Host Bootloader"
  },
  "systembooting-installer-part-scheme": {
    "link": "/docs/sysadmin.html#systembooting-installer-part-scheme",
    "title": "Partitioning Scheme Used by the Installer"
  },
  "systembooting-proxmox-boot-tool": {
    "link": "/docs/sysadmin.html#systembooting-proxmox-boot-tool",
    "title": "Synchronizing the Content of the ESP with ``proxmox-boot-tool``"
  },
  "systembooting-proxmox-boot-setup": {
    "link": "/docs/sysadmin.html#systembooting-proxmox-boot-setup",
    "title": "Setting up a New Partition for use as Synced ESP"
  },
  "systembooting-proxmox-boot-refresh": {
    "link": "/docs/sysadmin.html#systembooting-proxmox-boot-refresh",
    "title": "Updating the Configuration on all ESPs"
  },
  "systembooting-determine-bootloader": {
    "link": "/docs/sysadmin.html#systembooting-determine-bootloader",
    "title": "Determine which Bootloader is Used"
  },
  "systembooting-grub": {
    "link": "/docs/sysadmin.html#systembooting-grub",
    "title": "Grub"
  },
  "systembooting-grub-config": {
    "link": "/docs/sysadmin.html#systembooting-grub-config",
    "title": "Configuration"
  },
  "systembooting-systemdboot": {
    "link": "/docs/sysadmin.html#systembooting-systemdboot",
    "title": "Systemd-boot"
  },
  "systembooting-systemd-boot-config": {
    "link": "/docs/sysadmin.html#systembooting-systemd-boot-config",
    "title": "Configuration"
  },
  "systembooting-edit-kernel-cmdline": {
    "link": "/docs/sysadmin.html#systembooting-edit-kernel-cmdline",
    "title": "Editing the Kernel Commandline"
  },
  "systembooting-kernel-cmdline-grub": {
    "link": "/docs/sysadmin.html#systembooting-kernel-cmdline-grub",
    "title": "Grub"
  },
  "systembooting-kernel-cmdline-systemd-boot": {
    "link": "/docs/sysadmin.html#systembooting-kernel-cmdline-systemd-boot",
    "title": "systemd-boot"
  },
  "systembooting-kernel-pin": {
    "link": "/docs/sysadmin.html#systembooting-kernel-pin",
    "title": "Override the Kernel-Version for next Boot"
  },
  "systembooting-secure-boot": {
    "link": "/docs/sysadmin.html#systembooting-secure-boot",
    "title": "Secure Boot"
  },
  "systembooting-secure-boot-existing-installation": {
    "link": "/docs/sysadmin.html#systembooting-secure-boot-existing-installation",
    "title": "Switching an Existing Installation to Secure Boot"
  },
  "systembooting-secure-boot-existing-systemd-boot": {
    "link": "/docs/sysadmin.html#systembooting-secure-boot-existing-systemd-boot",
    "title": "**systemd-boot**"
  },
  "systembooting-secure-boot-other-modules": {
    "link": "/docs/sysadmin.html#systembooting-secure-boot-other-modules",
    "title": "Using DKMS/Third Party Modules With Secure Boot"
  },
  "sysadmin-certificate-management": {
    "link": "/docs/sysadmin.html#sysadmin-certificate-management",
    "title": "Certificate Management"
  },
  "sysadmin-certs-api-gui": {
    "link": "/docs/sysadmin.html#sysadmin-certs-api-gui",
    "title": "Certificates for the API and SMTP"
  },
  "sysadmin-certs-upload-custom": {
    "link": "/docs/sysadmin.html#sysadmin-certs-upload-custom",
    "title": "Upload Custom Certificate"
  },
  "sysadmin-certs-get-trusted-acme-cert": {
    "link": "/docs/sysadmin.html#sysadmin-certs-get-trusted-acme-cert",
    "title": "Trusted certificates via Let\u2019s Encrypt (ACME)"
  },
  "sysadmin-certs-acme-account": {
    "link": "/docs/sysadmin.html#sysadmin-certs-acme-account",
    "title": "ACME Account"
  },
  "sysadmin-certs-acme-plugins": {
    "link": "/docs/sysadmin.html#sysadmin-certs-acme-plugins",
    "title": "ACME Plugins"
  },
  "domains": {
    "link": "/docs/sysadmin.html#domains",
    "title": "Domains"
  },
  "sysadmin-certs-acme-http-challenge": {
    "link": "/docs/sysadmin.html#sysadmin-certs-acme-http-challenge",
    "title": "ACME HTTP Challenge Plugin"
  },
  "sysadmin-certs-acme-dns-challenge": {
    "link": "/docs/sysadmin.html#sysadmin-certs-acme-dns-challenge",
    "title": "ACME DNS API Challenge Plugin"
  },
  "sysadmin-certs-acme-dns-api-config": {
    "link": "/docs/sysadmin.html#sysadmin-certs-acme-dns-api-config",
    "title": "Configuring ACME DNS APIs for validation"
  },
  "dns-validation-through-cname-alias": {
    "link": "/docs/sysadmin.html#dns-validation-through-cname-alias",
    "title": "DNS Validation through CNAME Alias"
  },
  "sysadmin-certs-acme-dns-wildcard": {
    "link": "/docs/sysadmin.html#sysadmin-certs-acme-dns-wildcard",
    "title": "Wildcard Certificates"
  },
  "combination-of-plugins": {
    "link": "/docs/sysadmin.html#combination-of-plugins",
    "title": "Combination of Plugins"
  },
  "sysadmin-certs-acme-automatic-renewal": {
    "link": "/docs/sysadmin.html#sysadmin-certs-acme-automatic-renewal",
    "title": "Automatic renewal of ACME certificates"
  },
  "manually-change-certificate-over-command-line": {
    "link": "/docs/sysadmin.html#manually-change-certificate-over-command-line",
    "title": "Manually Change Certificate over the Command Line"
  },
  "tape-backup": {
    "link": "/docs/tape-backup.html#tape-backup",
    "title": "Tape Backup"
  },
  "tape-supported-hardware": {
    "link": "/docs/tape-backup.html#tape-supported-hardware",
    "title": "Supported Hardware"
  },
  "tape-changer-config": {
    "link": "/docs/tape-backup.html#tape-changer-config",
    "title": "Tape changers"
  },
  "tape-drive-config": {
    "link": "/docs/tape-backup.html#tape-drive-config",
    "title": "Tape drives"
  },
  "tape-media-pool-config": {
    "link": "/docs/tape-backup.html#tape-media-pool-config",
    "title": "Media Pools"
  },
  "tape-backup-job-config": {
    "link": "/docs/tape-backup.html#tape-backup-job-config",
    "title": "Tape Backup Jobs"
  },
  "tape-key-management": {
    "link": "/docs/tape-backup.html#tape-key-management",
    "title": "Encryption Key Management"
  },
  "tape-restore-encryption-key": {
    "link": "/docs/tape-backup.html#tape-restore-encryption-key",
    "title": "Restoring Encryption Keys"
  },
  "tech-design-overview": {
    "link": "/docs/technical-overview.html#tech-design-overview",
    "title": "Technical Overview"
  },
  "change-detection-mode-legacy": {
    "link": "/docs/technical-overview.html#change-detection-mode-legacy",
    "title": "Legacy Mode"
  },
  "change-detection-mode-data": {
    "link": "/docs/technical-overview.html#change-detection-mode-data",
    "title": "Data Mode"
  },
  "change-detection-mode-metadata": {
    "link": "/docs/technical-overview.html#change-detection-mode-metadata",
    "title": "Metadata Mode"
  },
  "terms": {
    "link": "/docs/terminology.html#terms",
    "title": "Terminology"
  },
  "term-backup-snapshot": {
    "link": "/docs/terminology.html#term-backup-snapshot",
    "title": "Backup Snapshot"
  },
  "user-mgmt": {
    "link": "/docs/user-management.html#user-mgmt",
    "title": "User Management"
  },
  "user-tokens": {
    "link": "/docs/user-management.html#user-tokens",
    "title": "API Tokens"
  },
  "user-acl": {
    "link": "/docs/user-management.html#user-acl",
    "title": "Access Control"
  },
  "user-tfa": {
    "link": "/docs/user-management.html#user-tfa",
    "title": "Two-Factor Authentication"
  },
  "user-tfa-setup-totp": {
    "link": "/docs/user-management.html#user-tfa-setup-totp",
    "title": "TOTP"
  },
  "user-tfa-setup-webauthn": {
    "link": "/docs/user-management.html#user-tfa-setup-webauthn",
    "title": "WebAuthn"
  },
  "user-tfa-setup-recovery-keys": {
    "link": "/docs/user-management.html#user-tfa-setup-recovery-keys",
    "title": "Recovery Keys"
  },
  "user-tfa-lockout": {
    "link": "/docs/user-management.html#user-tfa-lockout",
    "title": "Limits and Lockout of Two-Factor Authentication"
  },
  "user-realms-pam": {
    "link": "/docs/user-management.html#user-realms-pam",
    "title": "Linux PAM"
  },
  "user-realms-pbs": {
    "link": "/docs/user-management.html#user-realms-pbs",
    "title": "Proxmox Backup authentication server"
  },
  "user-realms-ldap": {
    "link": "/docs/user-management.html#user-realms-ldap",
    "title": "LDAP"
  },
  "user-realms-ad": {
    "link": "/docs/user-management.html#user-realms-ad",
    "title": "Active Directory"
  }
};
